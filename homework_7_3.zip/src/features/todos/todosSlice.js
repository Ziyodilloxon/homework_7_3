import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  todos: [],
  completedCount: 0,
  unCompletedCount: 0,
};

const todosSlice = createSlice({
  name: "todos",
  initialState,
  reducers: {
    addTodo: () => {},
    removeTodo: () => {},
    changeStatusTodo: () => {},
    calculateTotal: () => {},
  },
});
export const { addTodo, removeTodo, changeStatusTodo, calculateTotal } =
  todosSlice.actions;
export default todosSlice.reducer;
