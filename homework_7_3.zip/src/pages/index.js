export { default as Home } from "./Home";
export { default as About } from "./About";
export { default as Contact } from "./Contact";
export { default as Login } from "./Login";
export { default as Register } from "./Register";
